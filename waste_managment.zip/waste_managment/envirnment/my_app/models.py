from django.db import models

# Create your models here.
class bin_data(models.Model):
    city_name = models.CharField(max_length=50)
    area_name = models.CharField(max_length=50)
    locality_name = models.CharField(max_length=50)
    landmark_name = models.CharField(max_length=50)
    driver_email = models.EmailField(max_length=50)
    load_type = models.CharField(max_length=50)
    cycle_period = models.CharField(max_length=50)

class user_data(models.Model):
    u_name = models.CharField(max_length=50)
    u_f_name = models.CharField(max_length=50)
    u_l_name = models.CharField(max_length=50)
    u_email = models.EmailField(max_length=50,unique=True)
    m_no=models.CharField(max_length=10)
    u_pwd =models.CharField(max_length=20)
    friend_name = models.CharField(max_length=50)
    
class driver_data(models.Model):
    d_name = models.CharField(max_length=50)
    d_email = models.EmailField(max_length=50)
    d_pwd =models.CharField(max_length=20)
    city_name = models.CharField(max_length=50)
    d_adhr =models.CharField(max_length=10)
    mobile_no =models.CharField(max_length=10)
 
class complaints(models.Model):
    bin_id=models.CharField(max_length=2)
    area=models.CharField(max_length=50) 
    text=models.CharField(max_length=300)
    status=models.CharField(max_length=20)
    email = models.EmailField(max_length=50,default='@gmail.com')
    