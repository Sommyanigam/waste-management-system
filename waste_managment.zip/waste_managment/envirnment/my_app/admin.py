from django.contrib import admin
from my_app.models import user_data
# Register your models here.
admin.site.register(user_data)