from django.shortcuts import render,redirect
from django.http import request
from django.http import HttpResponse,HttpResponseRedirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from my_app.models import bin_data,user_data,driver_data,complaints

# Create your views here.
def landingpage(request):
    return render(request,"landing\landingpage.html")
####################################(user_register)########################
def u_reg(request):
    if request.method =='POST':
        name=request.POST.get('fname')+' '+request.POST.get('lname')
        d=user_data.objects.create(
            u_name = name,
            u_f_name = request.POST.get('fname'),
            u_l_name = request.POST.get('lname'),
            u_email = request.POST.get('Email'),
            m_no = request.POST.get('m_no'),
            u_pwd = request.POST.get('pwd1'),
            friend_name = request.POST.get('recheck')).save()
        u= User.objects.create_user(username=name,
                                    email=request.POST.get('Email'),
                                    password=request.POST.get('pwd1'))
        u.save()
        return HttpResponseRedirect('u_log')  
    return render(request,"landing/user_register.html")
####################################(ADMIN BLOCK) ######################################################
def add_log(request):
    if request.method =='POST':
        unm=request.POST.get('unm')
        pswd=request.POST.get('pswd')
        User=authenticate(username=unm,password=pswd)
        print("###############################",User)
        if User is not None:
           login(request,User)
           return render(request,"admin_block/admin_login.html")
    else:
        return render(request,"admin_block/loginpage.html")
@login_required(login_url='addd_log')
def homepage(request):
    return render(request,"admin_block/admin_login.html")  


@login_required(login_url='addd_log')  
def create_b(request):
    if request.method =='POST':
         c_name =request.POST.get('inputcity')
         a_name =request.POST.get('inputarea')
         l_name =request.POST.get('inputlocality')
         l_name =request.POST.get('inputlandmark')
         d_email = request.POST.get("inputAdriver")
         l_type =request.POST.get('inputltype')
         c_period =request.POST.get('inputcycleperiod')
         d=bin_data.objects.create( city_name=c_name,area_name=a_name,locality_name=l_name,landmark_name=l_name,
                                   driver_email=d_email,load_type=l_type,cycle_period=c_period)
         d.save()
         return HttpResponseRedirect('ad_log')
    return render(request,"admin_block/create_bin.html")

@login_required(login_url='addd_log')
def create_d(request):
    if request.method =='POST':
        d=driver_data.objects.create(
         d_name = request.POST.get('inputname'),
         d_email = request.POST.get('inputAdriver'),
         d_pwd =request.POST.get('inputpwd'),
         city_name =request.POST.get('inputcity'),
         d_adhr =request.POST.get('inputAadharno'),
         mobile_no=request.POST.get('inputmobileno'))
        d.save()
        return HttpResponseRedirect('ad_log')
    return render(request,"admin_block/create_driver.html")

@login_required(login_url='addd_log')
def update_b(request):
    b_data=bin_data.objects.all().values()
    return render(request,"admin_block/update_bin.html",{'allbin':b_data})

@login_required(login_url='addd_log')
def edit_bin(request,id):
    bin_d=bin_data.objects.get(id=id)
    return render(request,"admin_block/edit_bin.html",{'x':bin_d})

@login_required(login_url='addd_log')
def edit_bin2(request,id):
    if request.method =='POST':
         c_name =request.POST.get('inputcity')
         a_name =request.POST.get('inputarea')
         l_name =request.POST.get('inputlocality')
         l_name =request.POST.get('inputlandmark')
         d_email = request.POST.get("inputAdriver")
         l_type =request.POST.get('inputltype')
         c_period =request.POST.get('inputcycleperiod')
         d=bin_data.objects.filter(id=id).update( city_name=c_name,area_name=a_name,locality_name=l_name,landmark_name=l_name,
                                   driver_email=d_email,load_type=l_type,cycle_period=c_period)
         return HttpResponseRedirect('ad_log')
    return HttpResponse("data not saved")

@login_required(login_url='addd_log')
def user_de(request):
    b_data=user_data.objects.all().values()
    return render(request,"admin_block/user_details.html",{'allbin':b_data})

@login_required(login_url='addd_log')
def view_com(request):
    com=complaints.objects.all().values()
    print(com)
    return render(request,"admin_block/view_complaints.html",{'all_c':com})

@login_required(login_url='addd_log')
def view_com2(request,id):
    if request.method=='POST':
        c=complaints.objects.filter(id=id).update(
               status=request.POST.get('options')
        )
        return HttpResponseRedirect('/view_complaints')
           
@login_required(login_url='addd_log')
def view_d(request):
    drr_data=driver_data.objects.all().values()
    return render(request,"admin_block/view_driver.html",{'allbin':drr_data}) 

@login_required(login_url='addd_log')
def logout_d(request):
    logout(request)
    return render(request,"landing\landingpage.html")
###############(USER'S FUNCTION)#####################################################################
def user_log(request):
    if request.method =='POST':
        unm=request.POST.get('email')
        password=request.POST.get('pswd')
        d=user_data.objects.get(u_email=unm)
        User=authenticate(username=d.u_name,password=password)
        print("###############################",User)
        if User is not None:
            login(request,User)
            request.session['u_name']=d.u_name
            request.session['u_email']=d.u_email
            
            print(request.session.get('u_email'))
            print(request.session.get('u_name'))
            return render(request,"user/user_home.html")
        else:
            return render(request,"landing\landingpage.html")
    else:
           return render(request,"user/loginpage.html")

@login_required(login_url='userr_log')
def home_page(request):
    return render(request,"user/user_home.html")

@login_required(login_url='userr_log')
def reg_com(request):
    b_d=bin_data.objects.all().values()
    data={
        'allbin':b_d
    }
    return render(request,"user/register_complaint.html",data)        

@login_required(login_url='userr_log')
def write_com(request,id):
    c_d=bin_data.objects.filter(id=id).values()
    data={
        'allbin':c_d
    }
    return render(request,'user\write_complaint.html',data)        

@login_required(login_url='userr_log')
def write_com2(request):
    if request.method =='POST':
        d=complaints.objects.create(
         bin_id=request.POST.get('bin_id'),
         area=request.POST.get('inputarea'),
         text=request.POST.get('complain'),
         email=request.session.get('u_email'),
         status='pending')
        d.save
        return HttpResponseRedirect('/reg_com')
    return HttpResponse("data required")    
         
@login_required(login_url='userr_log')
def show(request):
    d=complaints.objects.filter(email=request.session.get('u_email')).values()
    data={
        'all_c':d
    } 
    for x in data['all_c']:
        print(x,"\n")
    return render(request,'user\my_complaint.html',{'all_c':d})

@login_required(login_url='userr_log')
def profile(request):
    d=user_data.objects.filter(u_email=request.session.get('u_email')).values()
    return render(request,"user\myprofile.html",{'x':d})

@login_required(login_url='userr_log')
def logout_u(request):
    print(request.session.get('u_email'))
    logout(request)
    print(request.session.get('u_email'))
    return redirect(landingpage)