"""
URL configuration for envirnment project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
import my_app.views as v

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',v.landingpage,name="landing_page"),
    ############(user's URL)#############
    path('home_user',v.home_page,name='homee_user'),
    path('us_reg',v.u_reg,name='user_reg'),
    path('u_log',v.user_log,name='userr_log'),
    path("reg_com",v.reg_com,name='register_com'),
    path('write_c/<int:id>',v.write_com,name='w_com'),
    path('write_c2',v.write_com2,name='w_com2'),
    path('show',v.show,name="show_complaints"),
    path('profile',v.profile,name="my_profile"),
    path('logout_user',v.logout_u,name="lout_u"),
    ############(admin's URL)######
    path('ad_log',v.add_log,name='addd_log'),
    path('home',v.homepage,name='homee'),
    path('create_bin',v.create_b,name='c_bin'),
    path('create_driver',v.create_d,name='c_driver'),
    path('update_bin',v.update_b,name='u_bin'),
    path('edit_bin/<int:id>',v.edit_bin,name='e_bin'),
    path('edit_bin2/<int:id>',v.edit_bin2,name='e_bin2'),
    path('user_details',v.user_de,name='u_details'),
    path('view_complaints',v.view_com,name='v_com'),
    path('v_com2/<int:id>',v.view_com2,name='v_com2'),
    path('view_driver',v.view_d,name='v_driver'),
    path('logout_driver',v.logout_d,name='log_driver')
]
    